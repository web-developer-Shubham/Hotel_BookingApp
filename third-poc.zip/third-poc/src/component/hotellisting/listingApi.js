import React, { Component } from "react";
import axios from "axios";
import ListingDisplay from "./listingDisplay";
import RoomFilter from "../filters/roomType";
import CostFilter from "../filters/costFilter";

const url = " https://developerfunnel.herokuapp.com/hotellist/";

class Details extends Component {
  constructor(props) {
    super(props);
    this.state = {
      hotelList: "",
    };
  }
  // setDataPerFilter(sortetdData) {
  //   this.setState({ hotelList: sortetdData });
  // }
  setDataPerFilter(sortedData) {
    this.setState({ hotelList: sortedData });
  }

  render() {
    return (
      <div className="row">
        <div className="col-md-2">
          <RoomFilter
            roomperType={(data) => {
              this.setDataPerFilter(data);
            }}
          />
          <hr />
          <CostFilter
            costperType={(data) => {
              this.setDataPerFilter(data);
            }}
          />
        </div>
        <div className="col-md-10">
          <ListingDisplay listData={this.state.hotelList} />
        </div>
      </div>
    );
  }
  componentDidMount() {
    var tripid = this.props.match.params.id;
    sessionStorage.setItem("tripType", tripid);
    axios.get(`${url}${tripid}`).then((response) => {
      this.setState({ hotelList: response.data });
    });
  }
}
export default Details;
