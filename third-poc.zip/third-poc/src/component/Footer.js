import React from "react";

const Footer = () => {
  return (
    <div>
      <small>&copy; ShubhamSaxena 2020</small>
    </div>
  );
};
export default Footer;
