import React from "react";
import { BrowserRouter, Route } from "react-router-dom";
import Home from "./home/Home";
import Header from "./Header";

import Footer from "./Footer";
import Listing from "./hotellisting/listingApi";
import Details from "./hoteldetails/hoteldetails";

import BookingForm from "./orders/forms";
import Orders from "./orders/bookingapi";

const Routing = () => {
  return (
    <BrowserRouter>
      <div>
        <Header />
        <Route exact path="/" component={Home} />
        <Route exact path="/list/:id" component={Listing} />
        <Route exact path="/details/:id" component={Details} />

        <Route path="/viewbooking" component={Orders} />
        <Route path="/booking/:id" component={BookingForm} />
        <Footer />
      </div>
    </BrowserRouter>
  );
};
export default Routing;
