import React from "react";
import { Link } from "react-router-dom";
import "./quicksearch.css";

const QuickDisplay = (props) => {
  const listTrips = ({ quickData }) => {
    if (quickData) {
      return quickData.map((item) => {
        return (
          <Link to={`/list/${item.trip}`}>
            <div className="tileContainer">
              <div className="tileComponent1">
                <img src={item.image} alt="d" />
              </div>
              <div className="tileComponent2">
                <div class="componentHeading">{item.name}</div>
                <div class="componentSubHeading">
                  start your trip with exclusive{item.name} options
                </div>
              </div>
            </div>
          </Link>
        );
      });
    }
  };
  return (
    <div className="quickSearchContainer">
      <p className="quickSearchHeding">Quick Search </p>
      <p className="quickSearchSubHeding">Discover trip by type </p>
      <br />
      {listTrips(props)}
    </div>
  );
};

export default QuickDisplay;
