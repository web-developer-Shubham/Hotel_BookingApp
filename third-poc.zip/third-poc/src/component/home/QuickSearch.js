import React, { Component } from "react";
import QuickDisplay from "./QuickDisplay";

var QuickUrl = "https://developerfunnel.herokuapp.com/booking/";

class QuickSearch extends Component {
  constructor() {
    super();
    this.state = {
      tripType: "",
    };
  }
  render() {
    console.log("Quick Search", this.state.tripType);
    return <QuickDisplay quickData={this.state.tripType} />;
  }
  componentDidMount() {
    fetch(QuickUrl, { Method: "Get" })
      .then((res) => res.json())
      .then((data) => {
        return this.setState({ tripType: data });
      });
  }
}
export default QuickSearch;
