import React, { Component } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import { Tab, Tabs, TabList, TabPanel } from "react-tabs";
import "react-tabs/style/react-tabs.css";
const url = "https://developerfunnel.herokuapp.com/hotelsdetails/";

class HotelDetails extends Component {
  constructor() {
    super();
    this.state = {
      hotel: {
        type: [{ name: "" }, { name: "" }, { name: "" }],
      },
      tripid: sessionStorage.getItem("tripType"),
    };

    console.log("ttrriipp:" + this.state.tripid);
  }
  render() {
    return (
      <div className="container">
        <div className="panel panel-info">
          <div className="panel-heading">
            <h2>{this.state.hotel.name}</h2>
          </div>
          <div className="panel-body">
            <div className="row">
              <div className="col-md-12">
                <img
                  className="img-responsive"
                  src={this.state.hotel.thumb}
                  alt="fdf"
                  style={{ height: 400, width: 1500 }}
                />
              </div>
              <div className="col-md-6">
                <h3>{this.state.hotel.name}</h3>
                <h3>{this.state.hotel.locality}</h3>
                <h3>{this.state.hotel.address}</h3>
              </div>
            </div>
          </div>
          <br />
          <div className="container">
            <Tabs>
              <TabList>
                <Tab>Overview</Tab>
                <Tab>Contact</Tab>
              </TabList>

              <TabPanel>
                <h3>About this place</h3>
                <div>Room type we offer:</div>
                <div>
                  <b>
                    {" "}
                    {this.state.hotel.type[0].name} |{" "}
                    {this.state.hotel.type[1].name} |{" "}
                    {this.state.hotel.type[2].name}{" "}
                  </b>
                </div>
                <div>
                  <b>Cost Per Night:{this.state.hotel.cost}</b>
                </div>
              </TabPanel>
              <TabPanel>
                <b>Contact number</b>
                <div>7415552821</div>
                <h5>{this.state.hotel.locality}</h5>
                <h5>{this.state.hotel.address}</h5>
              </TabPanel>
            </Tabs>
            <br />
            <Link to={`/list/${this.state.tripid}`} className="btn btn-danger">
              Back
            </Link>
            &nbsp;
            <Link
              to={`/booking/${this.props.match.params.id}`}
              className="btn btn-success"
            >
              Place Booking
            </Link>
          </div>
        </div>
      </div>
    );
  }
  componentDidMount() {
    var hotelId = this.props.match.params.id;
    axios.get(`${url}${hotelId}`).then((response) => {
      this.setState({ hotel: response.data[0] });
      //console.log(response.data);
    });
  }
}
export default HotelDetails;
