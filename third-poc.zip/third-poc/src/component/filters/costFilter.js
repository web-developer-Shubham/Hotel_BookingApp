import React, { Component } from "react";
import axios from "axios";

const url = "https://developerfunnel.herokuapp.com/hotellist";

class CostFilter extends Component {
  filterFunction = (event) => {
    let cost = event.target.value.split(",");
    let hcost = Number(cost[1]);
    let lcost = Number(cost[0]);
    let tripType = sessionStorage.getItem("tripType");
    var furl;
    if (event.target.value == "") {
      furl = `${url}/${tripType}`;
    } else {
      furl = `${url}/${tripType}?hcost=${hcost}&lcost=${lcost}`;
    }

    axios.get(furl).then((response) => {
      this.props.costperType(response.data);
    });
  };
  render() {
    return (
      <div>
        <center>Filter By Cost</center>
        <div onChange={this.filterFunction}>
          <label className="radio">
            <input type="radio" value="" name="room" />
            All
          </label>

          <label className="radio">
            <input type="radio" value="1000,3000" name="room" />
            1000-3000
          </label>

          <label className="radio">
            <input type="radio" value="3001,6000" name="room" />
            3001-6000
          </label>

          <label className="radio">
            <input type="radio" value="6001,16000" name="room" />
            6001-16000
          </label>
        </div>
      </div>
    );
  }
}
export default CostFilter;
