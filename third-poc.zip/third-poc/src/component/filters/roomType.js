import React, { Component } from "react";
import axios from "axios";

const url = "https://developerfunnel.herokuapp.com/hotellist";

class RoomFilter extends Component {
  filterFunction = (event) => {
    let roomtype = event.target.value;
    let tripType = sessionStorage.getItem("tripType");
    var furl;
    if (roomtype == "") {
      furl = `${url}/${tripType}`;
    } else {
      furl = `${url}/${tripType}?roomtype=${roomtype}`;
    }
    console.log("hhhh" + furl);
    axios.get(furl).then((response) => {
      this.props.roomperType(response.data);
    });
  };
  render() {
    return (
      <div>
        <center>Room Type</center>
        <div onChange={this.filterFunction}>
          <label className="radio">
            <input type="radio" value="" name="room" />
            All
          </label>

          <label className="radio">
            <input type="radio" value="1" name="room" />
            Deluxe Room
          </label>

          <label className="radio">
            <input type="radio" value="2" name="room" />
            Premium Room
          </label>

          <label className="radio">
            <input type="radio" value="3" name="room" />
            Travel Room
          </label>

          <label className="radio">
            <input type="radio" value="4" name="room" />
            Semi Deluxe Room
          </label>
        </div>
      </div>
    );
  }
}
export default RoomFilter;
