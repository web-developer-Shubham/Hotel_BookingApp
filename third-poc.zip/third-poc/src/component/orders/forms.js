import React, { Component } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

const url = "https://developerfunnel.herokuapp.com/hotelsdetails";
const bookingUrl = " https://developerfunnel.herokuapp.com/placeBooking";
class PlaceBooking extends Component {
  constructor() {
    super();
    this.state = {
      order_id: Math.floor(Math.random() * 10000),
      hotelname: "",
      name: "",
      phone: "",
      address: "",
      person: "",
    };
  }
  componentDidMount() {
    let hotelid = this.props.match.params.id;
    axios.get(`${url}/${hotelid}`).then((response) => {
      this.setState({ hotelname: response.data[0].name });
    });
  }
  handleChangeName = (event) => {
    this.setState({ name: event.target.value });
  };
  handleChangePhone = (event) => {
    this.setState({ phone: event.target.value });
  };
  handleChangeAddress = (event) => {
    this.setState({ address: event.target.value });
  };
  handleChangePerson = (event) => {
    this.setState({ person: event.target.value });
  };

  handleSubmit = () => {
    var data = {
      order_id: this.state.order_id,
      " hotelname": this.state.hotelname,
      name: this.state.name,
      phone: this.state.phone,
      address: this.state.address,
      person: this.state.person,
    };
    console.log(data);
    fetch(bookingUrl, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    }).then(this.props.history.push("/viewbooking"));
  };

  render() {
    return (
      <div className="container">
        <div className="panel panel-primary">
          <div className="panel-heading">
            <h4>Place Order</h4>
          </div>
          <div className="panel-body">
            <div className="form-group">
              <label>Order Id:</label>
              <input
                className="form-control"
                name="order_id"
                readOnly
                value={this.state.order_id}
              />
            </div>
            <div className="form-group">
              <label>Hotel Name:</label>
              <input
                className="form-control"
                name="hotel_name"
                readOnly
                value={this.state.hotelname}
              />
            </div>
            <div className="form-group">
              <label>Name:</label>
              <input
                className="form-control"
                name="name"
                onChange={this.handleChangeName}
                value={this.state.name}
              />
            </div>
            <div className="form-group">
              <label>Phone:</label>
              <input
                className="form-control"
                name="phone"
                onChange={this.handleChangePhone}
                value={this.state.phone}
              />
            </div>
            <div className="form-group">
              <label>Address:</label>
              <input
                className="form-control"
                name="address"
                onChange={this.handleChangeAddress}
                value={this.state.address}
              />
            </div>
            <div className="form-group">
              <label>How many persons:</label>
              <select
                className="form-control"
                name="person"
                onChange={this.handleChangePerson}
                value={this.state.person}
              >
                <option value="1">One</option>
                <option value="2">Two</option>
                <option value="3">Three</option>
                <option value="4">Four</option>
              </select>
            </div>
            <Link
              to={`/details/${this.props.match.params.id}`}
              className="btn btn-danger"
            >
              Cancel
            </Link>{" "}
            &nbsp;
            <button className="btn btn-success" onClick={this.handleSubmit}>
              Submit
            </button>
          </div>
        </div>
      </div>
    );
  }
}
export default PlaceBooking;
